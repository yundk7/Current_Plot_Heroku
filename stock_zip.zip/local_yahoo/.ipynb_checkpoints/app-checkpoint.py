import pandas as pd
pd.set_option('display.max_colwidth', -1)
import datetime as dt
import plotly as py
import plotly.graph_objs as go
py.offline.init_notebook_mode(connected = True)
from flask import Flask, request, render_template, session, redirect, jsonify
import matplotlib.pyplot as plt

# 2. Create an app, being sure to pass __name__
app = Flask(__name__)

# kr_stocks = ["삼성전자", "NAVER", "현대자동차", "카카오"]
# for i in range(0,len(kr_stocks)):
#     if i == 0:
#         kr_str = kr_stocks[0]
#     else:
#         kr_str = kr_str + ", " + kr_stocks[i]

# us_stocks = ["^GSPC","^DJI","^IXIC","AMZN","FB","GOOGL","NFLX","TSLA"]
# for i in range(0,len(us_stocks)):
#     if i ==0:
#         us_str = us_stocks[0]
#     else:
#         us_str = us_str + ", " + us_stocks[i]

    
# 3. Define what to do when a user hits the index route
@app.route("/")
def home():
#     home_df = pd.DataFrame()
#     page_df = ["/","/us","/kr"]
#     content_df = ['welcome to DQs stock comparison chart',us_str,kr_str]
#     home_df["page"] = page_df
#     home_df["content"] = content_df
    print("Server received request for 'Home' page...")
    return ("welcome to DQs stock comparison chart")

@app.route("/us", methods=["GET", "POST"])
def us():
    if request.method == "POST":
        mains = ["^GSPC","^DJI","^IXIC","^RUT"]
        main_names = ["S&P500","DOW30","NASDAQ","Russel2000"]
        dfs = []
        for main in mains:
            url = f'https://finance.yahoo.com/quote/{main}/history?p={main}'
            df = pd.read_html(url)[0][0:100]
            df.iloc[:,1:6] = df.iloc[:,1:6].astype(float)
            df["Date"]=pd.to_datetime(df["Date"])
            base = df.iloc[:,4][len(df)-1]
            df["c_base"] = df["Close*"]/base
            dfs.append(df)
        traces = []
        for n in range(len(main_names)):
            x = dfs[n]["Date"]
            y = dfs[n]["c_base"]
            trace = go.Scatter(x=x,y=y,
                           mode = 'lines',
                           name = main_names[n])
            traces.append(trace)
            
        stocks = request.form["symbols"]
        stocks = stocks.upper()
        stocks = str(stocks).replace(" ","").split(",")
        dfs = []
        for stock in stocks:
            url = f'https://finance.yahoo.com/quote/{stock}/history?p={stock}'
            df = pd.read_html(url)[0][0:100]
            df.iloc[:,1:6] = df.iloc[:,1:6].astype(float)
            df["Date"]=pd.to_datetime(df["Date"])
            base = df.iloc[:,4][len(df)-1]
            df["c_base"] = df["Close*"]/base
            dfs.append(df)

#         traces = []
        for n in range(len(stocks)):
            x = dfs[n]["Date"]
            y = dfs[n]["c_base"]
            trace = go.Scatter(x=x,y=y,
                           mode = 'lines',
                           name = stocks[n])
            traces.append(trace)

        fig = go.Figure(data=traces)
        py.offline.plot(fig,filename="templates/us.html",auto_open=False)
        return (render_template("us.html"))
#         return(py.plot(fig))
    return render_template("form.html")

@app.route("/kr", methods=["GET", "POST"])
def kr():
    if request.method == "POST":
        stocks = request.form["symbols"]
        stocks = stocks.upper()
        stocks = str(stocks).replace(" ","").split(",")

        symbols = pd.read_html("http://kind.krx.co.kr/corpgeneral/corpList.do?method=download&searchType=13",encoding="euc_kr")
        symbols = symbols[0]
        stocks_df = pd.DataFrame({"회사명": stocks})
        stocks_symbols = pd.merge(stocks_df,symbols)
        codes = stocks_symbols["종목코드"]
        results = 100

        dfs = []
        kos_name = ["코스피","코스피200","코스닥"]
        kos = ["KOSPI", "KPI200", "KOSDAQ"]
        for code in kos:
            for pg in range(1,int(results/6)+2):
                url = f"https://finance.naver.com/sise/sise_index_day.nhn?code={code}&page={pg}"
                if pg == 1:
                    df = pd.read_html(url)[0].dropna()
                else:
                    apnd = pd.read_html(url)[0].dropna()
                    df = df.append(apnd)
            df.reset_index(drop=True,inplace=True)
            df = df[0:results]
            df["날짜"] = pd.to_datetime(df["날짜"])
            df["비율"] = df["체결가"]/(df["체결가"][len(df)-1])
            dfs.append(df)

        traces = []
        for n in range(len(kos_name)):
            x = dfs[n]["날짜"]
            y = dfs[n]["비율"]
            trace = go.Scatter(x=x,y=y,
                           mode = 'lines',
                           name = kos_name[n])
            traces.append(trace)


        dfs=[]
        for code in codes:
            code = str(code).zfill(6)
            for pg in range(1,int(results/10)+2):
                url = f"https://finance.naver.com/item/sise_day.nhn?code={code}&page={pg}"
                if pg == 1:
                    df = pd.read_html(url)[0].dropna()
                else:
                    apnd = pd.read_html(url)[0].dropna()
                    df = df.append(apnd)
            df.reset_index(drop=True,inplace=True)
            df = df[0:results]
            df["날짜"] = pd.to_datetime(df["날짜"])
            df["비율"] = df["종가"]/(df["종가"][len(df)-1])
            dfs.append(df)

        for n in range(len(stocks)):
            x = dfs[n]["날짜"]
            y = dfs[n]["비율"]
            trace = go.Scatter(x=x,y=y,
                           mode = 'lines',
                           name = stocks[n])
            traces.append(trace)

        fig = go.Figure(data=traces)
        py.offline.plot(fig,filename="templates/kr.html")
        return render_template("kr.html")

    return render_template("form.html")
    
    
if __name__ == "__main__":
    app.run(debug=True)