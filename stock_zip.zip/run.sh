FLASK_APP=local_yahoo/main.py flask run
